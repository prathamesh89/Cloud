module.exports={
/*
* This file contains the configurations information of Twitter login app.
* It consists of Twitter app information, database information.
*/

	"facebook_api_key" 		: 			"532155750271192",
	"facebook_api_secret"	:				"d40685a09abefa179a03a12c514cc15e",
	"callback_url"				:				"http://facebooktest.com:8083/auth/facebook/callback",
	"use_database"				:				"false",
	"host"								:				"localhost",
	"username"						:				"root",
	"password"						:				"",
	"database"						:				""
}
